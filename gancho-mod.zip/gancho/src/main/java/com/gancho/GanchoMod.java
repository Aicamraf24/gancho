package com.gancho;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.server.ServerTickEvents;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.ExtraCodecs;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;

public class GanchoMod implements ModInitializer {
    public static final String MOD_ID = "gancho";

    /** Alcance máximo (en bloques) según la cantidad de cuerdas usadas (1 a 8). */
    public static final int[] RANGE_BY_ROPES = {20, 40, 60, 100, 120, 140, 160, 200};

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    /** Alcance guardado en el gancho con cuerda y en la ballesta equipada. */
    public static final DataComponentType<Integer> GRAPPLE_RANGE = Registry.register(
            BuiltInRegistries.DATA_COMPONENT_TYPE,
            id("grapple_range"),
            DataComponentType.<Integer>builder()
                    .persistent(ExtraCodecs.POSITIVE_INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT)
                    .build());

    public static final Item GRAPPLING_HOOK = registerItem("grappling_hook");
    public static final Item ROPED_HOOK = registerItem("roped_hook");

    public static final RecipeSerializer<HookCrossbowRecipe> HOOK_CROSSBOW_SERIALIZER = Registry.register(
            BuiltInRegistries.RECIPE_SERIALIZER,
            id("crafting_hook_crossbow"),
            new CustomRecipe.Serializer<>(HookCrossbowRecipe::new));

    private static Item registerItem(String name) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id(name));
        Item item = new Item(new Item.Properties().setId(key).stacksTo(1));
        return Registry.register(BuiltInRegistries.ITEM, key, item);
    }

    @Override
    public void onInitialize() {
        // Inventario creativo
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(entries -> entries.accept(GRAPPLING_HOOK));

        // Disparo: clic derecho con una ballesta con gancho que ya está cargada
        UseItemCallback.EVENT.register((player, level, hand) -> {
            ItemStack stack = player.getItemInHand(hand);
            Integer range = stack.get(GRAPPLE_RANGE);
            if (range == null || !stack.is(Items.CROSSBOW) || !CrossbowItem.isCharged(stack)) {
                return InteractionResult.PASS;
            }
            if (level instanceof ServerLevel serverLevel && player instanceof ServerPlayer serverPlayer) {
                GrappleManager.fire(serverPlayer, serverLevel, stack, hand, range);
            }
            return InteractionResult.SUCCESS;
        });

        // Arrastre del jugador tick a tick
        ServerTickEvents.END_SERVER_TICK.register(GrappleManager::tick);
    }
}
