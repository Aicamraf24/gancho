package com.gancho;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.ChargedProjectiles;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

public final class GrappleManager {
    private static final double SPEED = 1.6;      // bloques por tick
    private static final double STOP_DISTANCE = 2.0;

    private static final class Pull {
        final Vec3 target;
        int ticksLeft;
        Pull(Vec3 target, int ticksLeft) {
            this.target = target;
            this.ticksLeft = ticksLeft;
        }
    }

    private static final Map<UUID, Pull> PULLS = new HashMap<>();

    private GrappleManager() {}

    public static void fire(ServerPlayer player, ServerLevel level, ItemStack crossbow, InteractionHand hand, int range) {
        Vec3 start = player.getEyePosition();
        Vec3 end = start.add(player.getLookAngle().scale(range));
        BlockHitResult hit = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));

        if (hit.getType() != HitResult.Type.BLOCK) {
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.CROSSBOW_LOADING_END.value(), SoundSource.PLAYERS, 0.6F, 0.6F);
            player.displayClientMessage(Component.translatable("message.gancho.no_target", range), true);
            return;
        }

        Vec3 target = hit.getLocation();

        // Se gasta el proyectil cargado y la ballesta recibe desgaste
        crossbow.set(DataComponents.CHARGED_PROJECTILES, ChargedProjectiles.EMPTY);
        crossbow.hurtAndBreak(1, player,
                hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);

        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.CROSSBOW_SHOOT, SoundSource.PLAYERS, 1.0F, 0.8F);

        // "Cuerda" de partículas entre el jugador y el punto de impacto
        Vec3 dir = target.subtract(start);
        double dist = dir.length();
        double step = Math.max(1.0, dist / 60.0);
        Vec3 unit = dir.scale(1.0 / dist);
        for (double d = 1.0; d < dist; d += step) {
            Vec3 p = start.add(unit.scale(d));
            level.sendParticles(ParticleTypes.CRIT, p.x, p.y, p.z, 1, 0, 0, 0, 0);
        }

        int maxTicks = (int) Math.ceil(dist / SPEED) * 2 + 20;
        PULLS.put(player.getUUID(), new Pull(target, maxTicks));
    }

    public static void tick(MinecraftServer server) {
        Iterator<Map.Entry<UUID, Pull>> it = PULLS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Pull> entry = it.next();
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            Pull pull = entry.getValue();

            if (player == null || !player.isAlive()) {
                it.remove();
                continue;
            }

            Vec3 pos = player.position().add(0, player.getBbHeight() * 0.5, 0);
            Vec3 diff = pull.target.subtract(pos);
            double dist = diff.length();

            // Termina al llegar, por tiempo, o si el jugador se agacha para soltarse
            if (dist < STOP_DISTANCE || --pull.ticksLeft <= 0 || player.isShiftKeyDown()) {
                player.setDeltaMovement(player.getDeltaMovement().scale(0.3));
                player.hurtMarked = true;
                player.resetFallDistance();
                it.remove();
                continue;
            }

            double speed = Math.min(SPEED, dist * 0.6);
            player.setDeltaMovement(diff.scale(speed / dist));
            player.hurtMarked = true;
            player.resetFallDistance();
        }
    }
}
