package com.gancho;

import net.minecraft.network.chat.Component;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.item.crafting.CraftingBookCategory;
import net.minecraft.world.item.crafting.CraftingInput;
import net.minecraft.world.item.crafting.CustomRecipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.level.Level;

import java.util.List;

/** Ballesta + gancho con cuerda = ballesta con gancho (conserva encantamientos y desgaste). */
public class HookCrossbowRecipe extends CustomRecipe {

    public HookCrossbowRecipe(CraftingBookCategory category) {
        super(category);
    }

    @Override
    public boolean matches(CraftingInput input, Level level) {
        int crossbows = 0;
        int hooks = 0;
        for (int i = 0; i < input.size(); i++) {
            ItemStack s = input.getItem(i);
            if (s.isEmpty()) continue;
            if (s.is(Items.CROSSBOW)) {
                crossbows++;
            } else if (s.is(GanchoMod.ROPED_HOOK) && s.get(GanchoMod.GRAPPLE_RANGE) != null) {
                hooks++;
            } else {
                return false;
            }
        }
        return crossbows == 1 && hooks == 1;
    }

    @Override
    public ItemStack assemble(CraftingInput input) {
        ItemStack crossbow = ItemStack.EMPTY;
        int range = 0;
        for (int i = 0; i < input.size(); i++) {
            ItemStack s = input.getItem(i);
            if (s.is(Items.CROSSBOW)) {
                crossbow = s;
            } else if (s.is(GanchoMod.ROPED_HOOK)) {
                Integer r = s.get(GanchoMod.GRAPPLE_RANGE);
                if (r != null) range = r;
            }
        }
        ItemStack result = crossbow.copy();
        result.setCount(1);
        result.set(GanchoMod.GRAPPLE_RANGE, range);
        result.set(DataComponents.LORE, new ItemLore(List.of(
                Component.translatable("tooltip.gancho.equipped", range)
                        .withStyle(ChatFormatting.GRAY)
                        .withStyle(style -> style.withItalic(false)))));
        return result;
    }

    @Override
    public RecipeSerializer<? extends CustomRecipe> getSerializer() {
        return GanchoMod.HOOK_CROSSBOW_SERIALIZER;
    }
}
