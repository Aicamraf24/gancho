# Gancho (Fabric, Minecraft Java 26.1.2)

## Recetas
- **Gancho**: ` I ` / `ISI` / ` S ` (I = lingote de hierro, S = palo).
- **Gancho con cuerda**: gancho + 1 a 8 cuerdas en la mesa de crafteo (sin forma fija; el gancho al centro rodeado de cuerdas también sirve).
  Alcance: 1=20, 2=40, 3=60, 4=100, 5=120, 6=140, 7=160, 8=200 bloques.
- **Ballesta con gancho**: ballesta + gancho con cuerda (conserva encantamientos y desgaste).

## Uso
Carga la ballesta como siempre (necesita una flecha) y haz clic derecho: en vez de la flecha sale el gancho y te arrastra hasta el bloque que apuntas.
Agáchate (Shift) para soltarte en pleno vuelo. Si no hay superficie dentro del alcance, no se gasta nada.

## Compilar
Requiere JDK 25. En GitHub, el workflow `.github/workflows/build.yml` compila el jar y lo sube como artefacto.
